To Install this library into your Arduino IDE environment:

1. Place the root RFM73 folder in your installation libraries directory.
2. Startup (or restart) your Arduino IDE

For more information concerning installation of an Arduino library,
Please refer to http://www.arduino.cc 


